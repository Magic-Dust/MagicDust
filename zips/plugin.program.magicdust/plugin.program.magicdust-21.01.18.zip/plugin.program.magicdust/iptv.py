import xbmc

lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
title="MagicDust "
msg="Searching: " + lookfor
xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
space=lookfor.find(' ')
if space:
    lookfor =lookfor[0:space]

import re
import urllib2
import xbmcgui
from xbmcgui import ListItem

sources=['USA', 'USA2', 'USA3', 'UK', 'UK2', 'UK3', 'CAN', 'CAN2', 'CAN3', 'World', 'World2']
dialog = xbmcgui.Dialog()
ret = dialog.select("Choose a Cannel Source", sources)
source=sources[ret]

if source == "USA":
    url = "https://raw.githubusercontent.com/kilirushi/iptv/master/us.m3u"
    lookfor = r'INF:-1,(' + lookfor + r'[^\n]*)\n(ht[^#]*)'
elif source == "USA2":
    url = "https://raw.githubusercontent.com/wudongdefeng/IPTVCAT/master/data/countries/united%20states%20of%20america.json"
    lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
elif source == "USA3":
    url = "https://raw.githubusercontent.com/eliashussary/iptvcat-scraper/master/data/countries/united%20states%20of%20america.json"
    lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
elif source == "UK":
    url = "https://raw.githubusercontent.com/kilirushi/iptv/master/uk.m3u"
    lookfor = r'INF:-1,(' + lookfor + r'[^\n]*)\n(ht[^#]*)'
elif source == "UK2":
    url = "https://raw.githubusercontent.com/wudongdefeng/IPTVCAT/master/data/countries/united%20kingdom.json"
    lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
elif source == "UK3":
    url = "https://raw.githubusercontent.com/eliashussary/iptvcat-scraper/master/data/countries/united%20kingdom.json"
    lookfor = "(" +  lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
elif source == "CAN":
    url = "https://raw.githubusercontent.com/kilirushi/iptv/master/ca.m3u"
    lookfor = r'INF:-1,(' + lookfor + r'[^\n]*)\n(ht[^#]*)'
elif source == "CAN2":
    url = "https://raw.githubusercontent.com/wudongdefeng/IPTVCAT/master/data/countries/canada.json"
    lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
elif source == "CAN3":
    url = "https://raw.githubusercontent.com/eliashussary/iptvcat-scraper/master/data/countries/canada.json"
    lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
elif source == "World":
    url = "https://raw.githubusercontent.com/wudongdefeng/IPTVCAT/master/data/all-streams.json"
    lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
else:
    url = "https://raw.githubusercontent.com/eliashussary/iptvcat-scraper/master/data/all-streams.json"
    lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'

website = urllib2.urlopen(url)
html = website.read()
found=[]
links=[]

found=re.findall(lookfor, html, re.IGNORECASE)
for item in found:
    temp={}    
    temp=item[0]+" - "+item[1]+"??"
    links.append(temp)

if not links:
    xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
    sys.exit("No Stable Channels Found")
elif len(links) > 1:
    links = sorted(links, reverse = True)
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Choose Stream", links)
    lookfor = 'http[^?]*'
    html=links[ret]
    link = re.findall(lookfor, html, re.IGNORECASE)
    xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
else:
    lookfor = 'http[^?]*'
    html=links[0]
    link = re.findall(lookfor, html, re.IGNORECASE)
    xbmc.executebuiltin('PlayMedia(' + link[0] + ')')

#if ".m3u8" in link:
#xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
#else:
#    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER;url=' + link[0] + ')')