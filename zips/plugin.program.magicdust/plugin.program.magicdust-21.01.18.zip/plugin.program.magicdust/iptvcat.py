import xbmc

lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
title="MagicDust "
msg="Searching: " + lookfor
xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))

import re
import urllib2
import xbmcgui
from xbmcgui import ListItem

url = "https://raw.githubusercontent.com/wudongdefeng/IPTVCAT/master/data/countries/united%20states%20of%20america.json"
website = urllib2.urlopen(url)
html = website.read()

found=[]
links=[]
space=lookfor.find(' ')
if space:
    lookfor =lookfor[0:space]
lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
found=re.findall(lookfor, html, re.IGNORECASE)
for item in found:
    temp={}
    temp=item[2]+"% - "+item[0]+" - "+item[1]
    links.append(temp)

if not links:
    xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
    sys.exit("No Stable Channels Found")
elif len(links) > 1:
    links = sorted(links, reverse = True)
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Choose Stream", links)
    lookfor = 'http[^?]*'
    html=links[ret]
    link = re.findall(lookfor, html, re.IGNORECASE)
    xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
else:
    lookfor = 'http[^?]*'
    html=links[0]
    link = re.findall(lookfor, html, re.IGNORECASE)
    xbmc.executebuiltin('PlayMedia(' + link[0] + ')')