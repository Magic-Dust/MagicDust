import xbmc
import re
import xbmcgui
from xbmcgui import ListItem

filename = xbmc.translatePath("special://home/addons/plugin.program.magicdust/magic/channels.txt")
txt = open(filename)
html = txt.read()
lookfor = xbmc.getInfoLabel('ListItem.ChannelName')

found=[]
links=[]
lookfor = r'Channel:,([^,]*),(' + lookfor + r'),([^,]*),(.*)'
found=re.findall(lookfor, html)
for item in found:
    temp={}
    temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:    [COLOR=FF00FFFF]"+item[2]+"[/COLOR][/UPPERCASE][/B]  @"+item[3].replace('\n', ' ').replace('\r', '')
    links.append(temp)
txt.close
if not links:
    sources=['USA', 'USA2', 'UK', 'UK2', 'CAN', 'CAN2', 'World']
    lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
    space=lookfor.find(' ')
    if space:
        lookfor =lookfor[0:space]
    dialog = xbmcgui.Dialog()
    ret = dialog.select("No links found. Pick a deep search source:", sources)
    source=sources[ret]
    if source == "USA":
        url = "https://raw.githubusercontent.com/kilirushi/iptv/master/us.m3u"
        lookfor = r'INF:-1,(' + lookfor + r'[^\n]*)\n(ht[^#]*)'
    elif source == "USA2":
        url = "https://raw.githubusercontent.com/wudongdefeng/IPTVCAT/master/data/countries/united%20states%20of%20america.json"
        lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
    elif source == "UK":
        url = "https://raw.githubusercontent.com/kilirushi/iptv/master/uk.m3u"
        lookfor = r'INF:-1,(' + lookfor + r'[^\n]*)\n(ht[^#]*)'
    elif source == "UK2":
        url = "https://raw.githubusercontent.com/wudongdefeng/IPTVCAT/master/data/countries/united%20kingdom.json"
        lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
    elif source == "CAN":
        url = "https://raw.githubusercontent.com/kilirushi/iptv/master/ca.m3u"
        lookfor = r'INF:-1,(' + lookfor + r'[^\n]*)\n(ht[^#]*)'
    elif source == "CAN2":
        url = "https://raw.githubusercontent.com/wudongdefeng/IPTVCAT/master/data/countries/canada.json"
        lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
    elif source == "World":
        url = "https://raw.githubusercontent.com/wudongdefeng/IPTVCAT/master/data/all-streams.json"
        lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
    else:
        sys.exit("No Extra Channels Found")

    import urllib2
    website = urllib2.urlopen(url)
    html = website.read()
    found=[]
    links=[]
    found=re.findall(lookfor, html, re.IGNORECASE)
    for item in found:
        temp={}    
        temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:    [COLOR=FF00FFFF]"+item[1]+"[/COLOR][/UPPERCASE][/B]??"
        links.append(temp)
    website.close
    if not links:
        xbmc.executebuiltin('Notification(MagicDust ,No Extra Channels Found,5000)')
        sys.exit("No Stable Channels Found")
    elif len(links) > 0:
        links = sorted(links, reverse = True)
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose Stream", links)
        lookfor = 'http[^?]*'
        html=links[ret]
        link = re.findall(lookfor, html, re.IGNORECASE)
        xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
else:
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Choose Channel Source", links)
    if(ret)>0:
        lookfor = r'@(.*)'
        html=links[ret]
        link = re.findall(lookfor, html, re.IGNORECASE)
        xbmc.executebuiltin('PlayMedia("' + link[0] + '")')