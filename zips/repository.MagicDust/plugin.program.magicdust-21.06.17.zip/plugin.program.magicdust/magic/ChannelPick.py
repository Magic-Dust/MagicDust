import xbmc
import re
import xbmcgui
from xbmcgui import ListItem
import xbmcvfs

filename = xbmcvfs.translatePath('special://home/addons/plugin.program.magicdust/magic/channels.txt')
with xbmcvfs.File(filename) as file:
  html = file.read()
lookfor = xbmc.getInfoLabel('ListItem.ChannelName')

found=[]
links=[]
lookfor = r'Channel:,([^,]*),(' + lookfor + r'),([^,]*),(.*)'
found=re.findall(lookfor, html)

for item in found:
    temp={}
    temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:    [COLOR=FF00FFFF]"+item[2]+"[/COLOR][/UPPERCASE][/B]  @"+item[3].replace('\n', ' ').replace('\r', '')
    links.append(temp)

if not links:
    sources=['USA', 'UK', 'CAN', 'World']
    lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
    space=lookfor.find(' ')
    if space:
        lookfor =lookfor[0:space]
    dialog = xbmcgui.Dialog()
    ret = dialog.select("No links found. Pick a deep search source:", sources)
    source=sources[ret]
    #xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    if source == "USA":
        url = "https://raw.githubusercontent.com/wudongdefeng/IPTVCAT/master/data/countries/united%20states%20of%20america.json"
        lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
    elif source == "UK":
        url = "https://raw.githubusercontent.com/wudongdefeng/IPTVCAT/master/data/countries/united%20kingdom.json"
        lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
    elif source == "CAN":
        url = "https://raw.githubusercontent.com/wudongdefeng/IPTVCAT/master/data/countries/canada.json"
        lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
    elif source == "World":
        url = "https://raw.githubusercontent.com/wudongdefeng/IPTVCAT/master/data/all-streams.json"
        lookfor = "(" + lookfor + r'[^"]+)","link":"([^"]*").*?"liveliness":"([^"]+)".*?"status":"online'
    elif source == "IPTV-ORG":
        url = "https://raw.githubusercontent.com/iptv-org/iptv/master/channels/us.m3u"
        lookfor = r'",(' + lookfor + r'[^\n]*)\n(ht[^#]*)'
    else:
        sys.exit("No Extra Channels Found")

    import urllib.request
    from urllib.request import urlopen
    website = urlopen(url)
    with xbmcvfs.File(website) as f:
      html = f.readBytes()

    found=[]
    links=[]
    found=re.findall(lookfor, html, re.IGNORECASE)
    for item in found:
        temp={}    
        if source == "IPTV-ORG":
            temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:  [COLOR=FF00FFFF]100%   [/COLOR][/UPPERCASE][/B]- " +item[1]+"??"
            temp=temp.replace('\n', '').replace('\r', '')
        else:
            temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:  [COLOR=FF00FFFF]"+item[2]+"%   [/COLOR][/UPPERCASE][/B]- " +item[1]+"??"
        if temp not in links:
            links.append(temp)
    website.close
    if not links:
        xbmc.executebuiltin('Notification(MagicDust ,No Extra Channels Found,5000)')
        sys.exit("No Stable Channels Found")
    elif len(links) > 0:
        links = sorted(links, reverse = True)
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose Stream", links)
        lookfor = 'http[^?]*'
        html=links[ret]
        link = re.findall(lookfor, html, re.IGNORECASE)
        if(ret)>-1:
            if 'm3u8' in link[0]:
                xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
            else:
                xbmc.executebuiltin('PlayMedia("plugin://plugin.video.streamlink-tester/?action=play&url={0}&title={1}")'.format(quote(link[0]), 'manual'))
        else:
            sys.exit("No Stable Channels Found")
else:
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Choose Channel Source", links)
    if(ret)>-1:
        lookfor = r'@(.*)'
        html=links[ret]
        link = re.findall(lookfor, html, re.IGNORECASE)
        xbmc.executebuiltin('PlayMedia("' + link[0] + '")')
    else:
        sys.exit("No Stable Channels Found")