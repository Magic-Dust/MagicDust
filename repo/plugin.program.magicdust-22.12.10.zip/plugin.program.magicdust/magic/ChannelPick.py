import xbmc
import re
import xbmcgui
from xbmcgui import ListItem
import xbmcvfs
import time

filename = xbmcvfs.translatePath('special://home/addons/plugin.program.magicdust/magic/channels.txt')
with xbmcvfs.File(filename) as file:
  html = file.read()
lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
if not lookfor:
  xbmc.executebuiltin('ActivateWindow(TVGuide)')
  time.sleep(.200)
  lookfor = xbmc.getInfoLabel('ListItem.ChannelName')

found=[]
links=[]
lookfor = r'Channel:,([^,]*),(' + lookfor + r'),([^,]*),(.*)'
found=re.findall(lookfor, html)

import urllib.request
from urllib.request import urlopen

for item in found:
    temp={}
    temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:    [COLOR=FF00FFFF]"+item[2]+"[/COLOR][/UPPERCASE][/B]  @"+item[3].replace('\n', ' ').replace('\r', '')
    links.append(temp)

if not links:
    lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
    if not lookfor:
      xbmc.executebuiltin('ActivateWindow(TVGuide)')
      time.sleep(.200)
      lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
    space=lookfor.find(' ')
    if space > 1:
        lookfor =lookfor[0:space]
    name = lookfor
    source = "IPTV-Providers"
    url = "https://raw.githubusercontent.com/trincowski/iptv/main/Desportivos_World.m3u8"
    lookfor2 = r'(?i)BT SPORT 1[^\n]*\n(ht[^\/]*\/\/)([^\/]*)\/([^\/]*)\/([^\/]*)\/([^\/]*)'
    f = urllib.request.urlopen(url)
    html = f.read().decode('utf-8')
    found=[]
    links=[]
    found = re.findall(lookfor2, html)
    for item in found:
        temp={}    
        temp="[B][UPPERCASE][COLOR=green]"+item[1]+"[/COLOR]:  [COLOR=FF00FFFF]"+item[3] +"[/COLOR][/UPPERCASE][/B]- " +item[0]+item[1]+"/get.php?username="+item[3]+"&password="+item[4]+"&type=m3u&output=hls@"
        temp=temp.replace('\n', '').replace('\r', '')
        if temp not in links:
            links.append(temp)
    f.close
    if not links:
        xbmc.executebuiltin('Notification(MagicDust ,No Channels Found,5000)')
        sys.exit("No IPTV Services Found")
    elif len(links) > 0:
        links = sorted(links, reverse = True)
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose IPTV Service", links)
        lookfor2 = 'http[^@]*'
        html=links[ret]
        link = re.findall(lookfor2, html, re.IGNORECASE)
        url = link[0]
        lookfor = r'(?i)(' + lookfor + r'[^\n]*)\n(ht[^\n]*)'
        title="MagicDust "

        msg="Scraping " + name + " from " + source
        xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))

        user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36"
        req = urllib.request.Request(url, headers={'User-Agent': user_agent}, method='GET')
        f = urllib.request.urlopen(req)
        html = f.read().decode('utf-8')
        found=[]
        links=[]

        found = re.findall(lookfor, html)
        for item in found:
            temp={}    
            temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:  [COLOR=FF00FFFF]100%   [/COLOR][/UPPERCASE][/B]- " +item[1]+"??"
            temp=temp.replace('\n', '').replace('\r', '')
            if temp not in links:
                links.append(temp)
        f.close
        if not links:
            xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
            sys.exit("No Stable Channels Found")
        elif len(links) > 0:
            links = sorted(links, reverse = True)
            dialog = xbmcgui.Dialog()
            ret = dialog.select("Choose Stream", links)
            lookfor = 'http[^?]*'
            html=links[ret]
            link = re.findall(lookfor, html, re.IGNORECASE)
            if(ret)>-1:
#***find link within m3u8 subroutine***
                if 'IPTVCAT' in source:
                    found=[]
                    url = link[0]
                    hdr = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36", "Accept-Language": "en-US"}
                    req = urllib.request.Request(url, headers=hdr)
                    file = urllib.request.urlopen(req)
                    html = file.read().decode('utf-8')
                    lookfor = r'(?s)(?i)title=".+?(http[^?]*)'
                    found = re.findall(lookfor, html)
                    if 'm3u8' in found[0]:
                        xbmc.executebuiltin('PlayMedia(' + found[0] + ')')
                    else:
                        xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + found[0] + '")')
#***END find link within m3u8 routine***
                elif 'm3u8' in link[0]:
                    xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
                else:
                    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + link[0] + '")')
else:
    name = lookfor
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Choose a Local Channel Source", links)
    if(ret)>-1:
        lookfor = r'@(.*)'
        html=links[ret]
        link = re.findall(lookfor, html, re.IGNORECASE)
        if '.ts' in link[0]:
            xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + link[0] + '")')
        elif 'f4m' in link[0]:
            xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + link[0] + '")')
        else:
            xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
    else:
        xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
        sys.exit("No Stable Channels Found")