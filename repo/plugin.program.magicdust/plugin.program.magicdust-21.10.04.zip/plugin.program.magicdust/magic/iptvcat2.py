import xbmc
import time

lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
if not lookfor:
  xbmc.executebuiltin('ActivateWindow(TVGuide)')
  time.sleep(.200)
  lookfor = xbmc.getInfoLabel('ListItem.ChannelName')

title="MagicDust "
msg="Searching: " + lookfor
xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
space=lookfor.find(' ')
name=lookfor
if space:
    lookfor =lookfor[0:space]

import re
import xbmcgui
from xbmcgui import ListItem

sources=['USA-IPTVCAT', 'USA-kilirushi', 'USA-IPTV-ORG', 'USA-GunzoMan', 'USA-Fermiranda', '==============', 'UK-IPTVCAT', 'UK-kilirushi', 'UK-IPTV-ORG', '==============', 'CAN-IPTVCAT', 'CAN-kilirushi', 'CAN-IPTV-ORG']
dialog = xbmcgui.Dialog()
ret = dialog.select("Choose an Online Channel Source", sources)
source=sources[ret]

if source == "USA-kilirushi":
    url = "https://raw.githubusercontent.com/kilirushi/iptv/master/us.m3u"
    lookfor = r'(?i)(' + lookfor + r'[^\n]*)\n(ht[^#]*)'
elif source == "UK-kilirushi":
    url = "https://raw.githubusercontent.com/kilirushi/iptv/master/uk.m3u"
    lookfor = r'(?i)(' + lookfor + r'[^\n]*)\n(ht[^#]*)'
elif source == "CAN-kilirushi":
    url = "https://raw.githubusercontent.com/kilirushi/iptv/master/ca.m3u"
    lookfor = r'(?i)(' + lookfor + r'[^\n]*)\n(ht[^#]*)'
elif source == "USA-IPTV-ORG":
    url = "https://raw.githubusercontent.com/iptv-org/iptv/master/channels/us.m3u"
    lookfor = r'(?i)",(' + lookfor + r'[^"]*)\n(ht[^#]*)'
elif source == "UK-IPTV-ORG":
    url = "https://raw.githubusercontent.com/iptv-org/iptv/master/channels/uk.m3u"
    lookfor = r'(?i)",(' + lookfor + r'[^"]*)\n(ht[^#]*)'
elif source == "CAN-IPTV-ORG":
    url = "https://raw.githubusercontent.com/iptv-org/iptv/master/channels/ca.m3u"
    lookfor = r'(?i)",(' + lookfor + r'[^"]*)\n(ht[^#]*)'
elif source == "USA-IPTVCAT":
    url = "https://raw.githubusercontent.com/ericziethen/ez-iptvcat-scraper/master/data/countries/united%20states%20of%20america.json"
    lookfor = r'(?s)(?i)('+ lookfor + r'[^"]*).+?link":[^"]*"([^?]*).+?"status": "([^"]*)'
elif source == "UK-IPTVCAT":
    url = "https://github.com/ericziethen/ez-iptvcat-scraper/raw/master/data/countries/united%20kingdom.json"
    lookfor = r'(?s)(?i)('+ lookfor + r'[^"]*).+?link":[^"]*"([^?]*).+?"status": "([^"]*)'
elif source == "CAN-IPTVCAT":
    url = "https://github.com/ericziethen/ez-iptvcat-scraper/raw/master/data/countries/canada.json"
    lookfor = r'(?s)(?i)('+ lookfor + r'[^"]*).+?link":[^"]*"([^?]*).+?"status": "([^"]*)'
elif source == "USA-GunzoMan":
    url = "https://github.com/gunzoman14/GunzoMan/raw/main/IPTV"
    lookfor = r'(?i)(' + lookfor + r'[^"]*)\n(ht[^#]*)'
elif source == "USA-Fermiranda":
    url = "https://github.com/fermiranda/lista/raw/master/MITv.m3u"
    lookfor = r'(?i)(' + lookfor + r'[^"]*)\n(ht[^#]*)'
else:
    sys.exit("No Extra Channels Found")

import urllib.request
from urllib.request import urlopen

f = urllib.request.urlopen(url)
html = f.read().decode('utf-8')

found=[]
links=[]

found = re.findall(lookfor, html)
#found = re.findall(lookfor, html, re.IGNORECASE)
for item in found:
    temp={}    
    if 'IPTV-ORG' in source:
        temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:  [COLOR=FF00FFFF]100%   [/COLOR][/UPPERCASE][/B]- " +item[1]+"??"
        temp=temp.replace('\n', '').replace('\r', '')
    elif 'IPTVCAT' in source:
        temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:  [COLOR=FF00FFFF]"+item[2]+"    [/COLOR][/UPPERCASE][/B]- " +item[1]+"??"
        temp=temp.replace('\n', '').replace('\r', '')
    else:
        temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:  [COLOR=FF00FFFF]100%   [/COLOR][/UPPERCASE][/B]- " +item[1]+"??"
        temp=temp.replace('\n', '').replace('\r', '')
    if temp not in links and 'offline' not in temp:
        links.append(temp)
f.close

if not links:
    xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
    sys.exit("No Stable Channels Found")
elif len(links) > 0:
    links = sorted(links, reverse = True)
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Choose Stream", links)
    if(ret)>-1:
        lookfor = 'http[^?]*'
        html=links[ret]
        link = re.findall(lookfor, html, re.IGNORECASE)
        xbmc.executebuiltin('PlayMedia(' + link[0] + ')')        
        #xbmc.executebuiltin('PlayMedia("plugin://plugin.video.streamlink-tester/?action=play&url='+ link[0] + '")')
    else:
        sys.exit("No Stable Channels Found")
else:
    xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
    sys.exit("No Stable Channels Found")