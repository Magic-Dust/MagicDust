import xbmc
import re
import xbmcgui
from xbmcgui import ListItem
import xbmcvfs
import time

filename = xbmcvfs.translatePath('special://home/addons/plugin.program.magicdust/magic/channels.txt')
with xbmcvfs.File(filename) as file:
  html = file.read()
lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
if not lookfor:
    xbmc.executebuiltin('ActivateWindow(TVGuide)')
    time.sleep(.500)
    lookfor = xbmc.getInfoLabel('ListItem.ChannelName')

found=[]
links=[]
lookfor2=r'Channel:,([^,]*),(' + lookfor + r'),([^,]*),(.*)'
found = re.findall(lookfor2, html)

for item in found:
    temp={}
    temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:    [COLOR=FF00FFFF]"+item[2]+"[/COLOR][/UPPERCASE][/B]  @"+item[3].replace('\n', ' ').replace('\r', '')    
    temp=temp.replace('\n', '').replace('\r', '')
    if temp not in links:
        links.append(temp)
file.close
if not links:
    import urllib.request
    from urllib.request import urlopen
    lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
    if not lookfor:
        xbmc.executebuiltin('ActivateWindow(TVGuide)')
        time.sleep(.200)
        lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
    space=lookfor.find(' ')
    if space > 1:
        lookfor =lookfor[0:space]
    name=lookfor
    title="MagicDust "
    url = 'https://onedrive.live.com/download?cid=E28369FD4B5A92DC&resid=E28369FD4B5A92DC%21155&authkey=AAZvbY0ngUf6rKE'
    lookfor2 = r'(?i),.*IPTV[^\n]*\n(ht[^\/]*\/\/)([^\/]*)\/([^\/]*)\/([^\/]*)\/([^\/]*)'
    lookfor3 = r'(?i),(.*Github[^\n]*)\n+(http[^\n]*)'
    lookfor4 = r'(?i),(.*Loop[^\n]*)\n+(http[^\n]*)'

    f = urllib.request.urlopen(url)
    html = f.read().decode('utf-8')
    found=[]
    links=[]
    found = re.findall(lookfor2, html)
    for item in found:
        temp={}
        temp="[B][UPPERCASE][COLOR=yellow]"+item[1]+"[/COLOR]:  [COLOR=FF00FFFF]"+item[3] +"[/COLOR][/UPPERCASE][/B]- " +item[0]+item[1]+"/get.php?username="+item[3]+"&password="+item[4]+"&type=m3u@"
        temp=temp.replace('\n', '').replace('\r', '')
        if temp not in links:
            links.append(temp)
    found=[]
    found = re.findall(lookfor3, html)
    for item in found:
        temp={}    
        temp="[B][UPPERCASE][COLOR=orange]"+item[0]+"[/COLOR][/UPPERCASE][/B]- " +item[1] +"@"
        temp=temp.replace('\n', '').replace('\r', '')
        if temp not in links:
            links.append(temp)
    found=[]
    found = re.findall(lookfor4, html)
    for item in found:
        temp="[B][UPPERCASE][COLOR=green] the Loop [/COLOR][/UPPERCASE][/B]- " +item[1] +"@"
        temp=temp.replace('\n', '').replace('\r', '')
        if temp not in links:
            links.append(temp)
    f.close
    if not links:
        xbmc.executebuiltin('Notification(MagicDust ,No IPTV Services Found,5000)')
        sys.exit("No IPTV Services Found")
    elif len(links) > 0:
        links = sorted(links, reverse = False)
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose IPTV Service Source", links)
        lookfor10 = 'http[^@]*'
        html=links[ret]
        checker = "Loop"
        msg="Scraping " + name + " from " + html
        xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
        link = re.findall(lookfor10, html, re.IGNORECASE)
        url = link[0]
        user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36"
        req = urllib.request.Request(url, headers={'User-Agent': user_agent}, method='GET')
        f = urllib.request.urlopen(req)
        html = f.read().decode('utf-8')
        found=[]
        links=[]
        if checker in html:
            ptvscan = r'(?i)<(.*' + name + r'[^\n]*)\n([^\n]*)'
        else:
            iptvscan = r'(?i),(.*' + name + r'[^\n]*)\n(ht[^\n]+)'
        found = re.findall(iptvscan, html)
        for item in found:
            temp={}    
            temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR][/UPPERCASE][/B] - " +item[1]+"??"
            temp=temp.replace('\n', '').replace('\r', '')
            if temp not in links and 'offline' not in temp:
                links.append(temp)
        f.close
        if not links:
            xbmc.executebuiltin('Notification(MagicDust ,No Channels Found,5000)')
            sys.exit("No Stable Channels Found")
        elif len(links) > 0:
            links = sorted(links, reverse = False)
            dialog = xbmcgui.Dialog()
            ret = dialog.select("Choose Stream", links)
            html=links[ret]
            checker = "plugin"
            if checker in html:
                lookfor = 'plugin[^?]*'
            else:
                lookfor = 'http[^?]*'
            link = re.findall(lookfor, html, re.IGNORECASE)
            if(ret)>-1:
                xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
        else:
            xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
            sys.exit("No Stable Channels Found")
else:
    name = lookfor
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Choose a Local Channel Source", links)
    if(ret)>-1:
        lookfor = r'@(.*)'
        html=links[ret]
        link = re.findall(lookfor, html, re.IGNORECASE)
        if '.ts' in link[0]:
            xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + link[0] + '")')
        elif 'f4m' in link[0]:
            xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + link[0] + '")')
        else:
            xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
    else:
        xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
        sys.exit("No Stable Channels Found")
