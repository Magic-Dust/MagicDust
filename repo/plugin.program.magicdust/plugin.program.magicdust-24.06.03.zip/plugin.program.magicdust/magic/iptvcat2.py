import xbmc
import time
import re

lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
if not lookfor:
    xbmc.executebuiltin('ActivateWindow(TVGuide)')
    time.sleep(.200)
    lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
space=lookfor.find(' ')
if space > 1:
    lookfor =lookfor[0:space]
name=lookfor
title="MagicDust "

url = 'https://onedrive.live.com/download?cid=E28369FD4B5A92DC&resid=E28369FD4B5A92DC%21155&authkey=AAZvbY0ngUf6rKE'
import urllib.request
from urllib.request import urlopen
f = urllib.request.urlopen(url)
html = f.read().decode('utf-8')

IPTVsearch = r'(?i),.*IPTV[^\n]*\n(ht[^\/]*\/\/)([^\/]*)\/([^\/]*)\/([^\/]*)\/([^\/]*)'
Gitsearch = r'(?i),(.*Github[^\n]*)\n+(http[^\n]*)'
Loopsearch = r'(?i),(.*Loop[^\n]*)\n+(http[^\n]*)'

found=[]
links=[]
found = re.findall(IPTVsearch, html)
for item in found:
    temp={}
    temp="[B][UPPERCASE][COLOR=yellow]"+item[1]+"[/COLOR]:  [COLOR=FF00FFFF]"+item[3] +"[/COLOR][/UPPERCASE][/B]- " +item[0]+item[1]+"/get.php?username="+item[3]+"&password="+item[4]+"&type=m3u@"
    temp=temp.replace('\n', '').replace('\r', '')
    if temp not in links:
        links.append(temp)
found=[]
found = re.findall(Gitsearch, html)
for item in found:
    temp={}    
    temp="[B][UPPERCASE][COLOR=orange]"+item[0]+"[/COLOR][/UPPERCASE][/B]- " +item[1] +"@"
    temp=temp.replace('\n', '').replace('\r', '')
    if temp not in links:
        links.append(temp)
found=[]
found = re.findall(Loopsearch, html)
for item in found:
    temp="[B][UPPERCASE][COLOR=green] the Loop [/COLOR][/UPPERCASE][/B]- " +item[1] +"@"
    temp=temp.replace('\n', '').replace('\r', '')
    if temp not in links:
        links.append(temp)
f.close
if not links:
    xbmc.executebuiltin('Notification(MagicDust ,No IPTV Services Found,5000)')
    sys.exit("No IPTV Services Found")

import xbmcgui
from xbmcgui import ListItem
if len(links) > 0:
    links = sorted(links, reverse = False)
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Choose IPTV Service Source", links)
    Sourcesearch = 'http[^@]*'
    html=links[ret]
    if "iptv-org" in html:
        direct = 0
    else:
        direct = 1
    checker = "loop"
    msg="Scraping " + name + " from " + html
    xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
    link = re.findall(Sourcesearch, html, re.IGNORECASE)
    url = link[0]
    if checker in url:
        iptvscan = r'(?i)<.*(' + name + r'[^\n]*)\n([^\n]*)'
        from cloudscraper2 import CloudScraper
        import requests
        scraper = CloudScraper.create_scraper(browser='chrome')
        user_agent = "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.42"
        scraper.headers.update({'User-Agent': user_agent})
        cookies = scraper.get(url).cookies.get_dict()
        req = urllib.request.Request(url, method='GET')
        req.add_header('User-Agent', user_agent)
        req.add_header('cookie', 'cookies')
        f = urllib.request.urlopen(req,timeout=12)
    else:
        iptvscan = r'(?i),(.*' + name + r'[^\n]*)\n(ht[^\n]+)'
        f = urllib.request.urlopen(url)    
    html = f.read().decode('utf-8')
    found=[]
    links=[]
    found = re.findall(iptvscan, html)
    for item in found:
        temp={}    
        temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR][/UPPERCASE][/B] - " +item[1]+"??"
        temp=temp.replace('\n', '').replace('\r', '')
        if temp not in links and 'offline' not in temp:
            links.append(temp)
    f.close
    if not links:
        xbmc.executebuiltin('Notification(MagicDust ,No Channels Found,5000)')
        sys.exit("No Stable Channels Found")
    elif len(links) > 0:
        links = sorted(links, reverse = False)
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose Stream", links)
        html=links[ret]
        checker = "plugin"
        if checker in html:
            lookfor = 'plugin[^?]*'
        else:
            lookfor = 'http[^?]*'
        link = re.findall(lookfor, html, re.IGNORECASE)
        if len(link[0]) > 0:
        #if(ret)>-1:
            #if link[0].startswith("plugin"):
            if "plugin" in link[0]:
                msg="running plugin " + link[0]
                xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
                xbmc.executebuiltin(f"RunPlugin({link[0]})")
            elif direct: 
                msg="running jetproxy " + link[0]
                xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
                xbmc.executebuiltin('RunPlugin(plugin://plugin.video.jetproxy/play/' + link[0] + ')')
            else:
                msg="direct player " + link[0]
                xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
                xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
        else:
            xbmc.executebuiltin('Notification(MagicDust ,Unplayable Channel,5000)')
            sys.exit("No Stable Channels Found")
    else:
        xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
        sys.exit("No Stable Channels Found")
else:
    xbmc.executebuiltin('Notification(MagicDust ,No IPTV Services Found,5000)')
    sys.exit("No IPTV Services Found")