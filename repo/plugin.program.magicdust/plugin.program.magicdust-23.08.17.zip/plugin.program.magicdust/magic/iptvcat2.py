import xbmc
import time
import re
import xbmcgui
from xbmcgui import ListItem

lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
if not lookfor:
    xbmc.executebuiltin('ActivateWindow(TVGuide)')
    time.sleep(.200)
    lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
space=lookfor.find(' ')
if space > 1:
    lookfor =lookfor[0:space]
name=lookfor

title="MagicDust "
#msg="Searching: " + name + " sources"
#xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))

sources=['USA\World-Fermiranda', 'USA\World-Magic-IPTV', 'USA\World-FreeIPTV', 'USA\World-GMTV', 'USA-IPTVCAT', 'USA-IPTV-ORG', 'MadTitan-TAILS']
#, '==========UK===========', 'UK-IPTVCAT', 'UK-IPTV-ORG', '==========CA===========', 'CAN-IPTVCAT', 'CA-IPTV-ORG']
dialog = xbmcgui.Dialog()
ret = dialog.select("Choose Online Channel Source", sources)
source=sources[ret]

import urllib.request
from urllib.request import urlopen
#import xbmcvfs

if source == "MadTitan-TAILS":
    msg="Scraping " + name + " wait 10 sec..."
    xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/xtream_server/search/us?query=' + name + '",return)')
    sys.exit("Scraping Channels apx 10 sec")

elif source == "USA\World-Magic-IPTV":
    url = 'https://onedrive.live.com/download?cid=E28369FD4B5A92DC&resid=E28369FD4B5A92DC%21155&authkey=AAZvbY0ngUf6rKE'
    #filename = xbmcvfs.translatePath('special://home/addons/plugin.program.magicdust/magic/m3ulist.txt')
    #with xbmcvfs.File(filename) as file:
        #html = file.read()
        #lookfor2 = r'(?i),.*LIVE[^\n]*\n(ht[^\/]*\/\/)([^\/]*)\/([^\/]*)\/([^\/]*)\/([^\/]*)'
    lookfor2 = r'(?i),.*LIVE[^\n]*\n(ht[^\/]*\/\/)([^\/]*)\/([^\/]*)\/([^\/]*)\/([^\/]*)'
    f = urllib.request.urlopen(url)
    html = f.read().decode('utf-8')
    found=[]
    links=[]
    found = re.findall(lookfor2, html)
    for item in found:
        temp={}    
        temp="[B][UPPERCASE][COLOR=green]"+item[1]+"[/COLOR]:  [COLOR=FF00FFFF]"+item[3] +"[/COLOR][/UPPERCASE][/B]- " +item[0]+item[1]+"/get.php?username="+item[3]+"&password="+item[4]+"&type=m3u&output=hls@"
        temp=temp.replace('\n', '').replace('\r', '')
        if temp not in links:
            links.append(temp)
    #file.close
    f.close
    if not links:
        xbmc.executebuiltin('Notification(MagicDust ,No IPTV Services Found,5000)')
        sys.exit("No IPTV Services Found")
    elif len(links) > 0:
        links = sorted(links, reverse = False)
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose IPTV Source", links)
        lookfor2 = 'http[^@]*'
        html=links[ret]
        link = re.findall(lookfor2, html, re.IGNORECASE)
        url = link[0]
        lookfor = r'(?i),(.*' + lookfor + r'[^\n]*)\n(ht[^\n]+)'

elif source == "USA\World-FreeIPTV":
    from cloudscraper2 import CloudScraper
    import requests
    #url = "https://world.freeiptv.life/2022/12/free-iptv-links-daily-m3u-playlists-14.html"
    scraper = CloudScraper.create_scraper(browser='chrome')
    url = 'https://world.freeiptv.life/index.html'
    user_agent = "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.42"
    scraper.headers.update({'User-Agent': user_agent})
    cookies = scraper.get(url).cookies.get_dict()
    headers = {'User-Agent': user_agent}
    req = urllib.request.Request(url, method='GET')
    req.add_header('User-Agent', user_agent)
    req.add_header('cookie', 'cookies')
    f = urllib.request.urlopen(req,timeout=12)
    html = f.read().decode('utf-8')
    found=[]
    links=[]
    lookfor2 = r'<a class='+"'"+'entry-thumbnail'+"'"+' href="([^"]+)" title='+"'"+'([^'+"'"+']+)'
    found = re.findall(lookfor2, html)
    for item in found:
        temp={}    
        temp=item[1]+" :  "+item[0]+"@"
        temp=temp.replace('\n', '').replace('\r', '')
        if temp not in links:
            links.append(temp)
    f.close
    if not links:
        xbmc.executebuiltin('Notification(MagicDust ,No IPTV Services Found,5000)')
        sys.exit("No IPTV Services Found")
    if len(links) > 0:
        links = sorted(links, reverse = True)
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose FreeIPTV Date", links)
        lookfor2 = 'http[^@]*'
        html=links[ret]
        link = re.findall(lookfor2, html, re.IGNORECASE)
        url = link[0]
        cookies = scraper.get(url).cookies.get_dict()
        req = urllib.request.Request(url, method='GET')
        req.add_header('User-Agent', user_agent)
        req.add_header('cookie', 'cookies')
        f = urllib.request.urlopen(req,timeout=12)
        html = f.read().decode('utf-8')
        found=[]
        links=[]
        lookfor2 = r'id="([^"]+)"><code>(http[^<]+)'
        found = re.findall(lookfor2, html)
        for item in found:
            temp={}    
            temp=item[0]+ " - " +item[1]+"@"
            temp=temp.replace('\n', '').replace('\r', '')
            if temp not in links:
                links.append(temp)
        f.close
        if len(links) > 0:
            links = sorted(links, reverse = False)
            dialog = xbmcgui.Dialog()
            ret = dialog.select("Choose IPTV List", links)
            lookfor2 = 'http[^@]*'
            html=links[ret]
            link = re.findall(lookfor2, html, re.IGNORECASE)
            url = link[0]
            lookfor = r'(?i),(.*' + lookfor + r'[^\n]*)\n(ht[^\n]+)'

#not working
elif source == "USA\World-Trincowski":
    url = "https://raw.githubusercontent.com/trincowski/iptv/main/Desportivos_World.m3u8"
    lookfor2 = r'(?i)BT SPORT 1[^\n]*\n(ht[^\/]*\/\/)([^\/]*)\/([^\/]*)\/([^\/]*)\/([^\/]*)'
    f = urllib.request.urlopen(url)
    html = f.read().decode('utf-8')
    found=[]
    links=[]
    found = re.findall(lookfor2, html)
    for item in found:
        temp={}    
        temp="[B][UPPERCASE][COLOR=green]"+item[1]+"[/COLOR]:  [COLOR=FF00FFFF]"+item[3] +"[/COLOR][/UPPERCASE][/B]- " +item[0]+item[1]+"/get.php?username="+item[3]+"&password="+item[4]+"&type=m3u&output=hls@"
        temp=temp.replace('\n', '').replace('\r', '')
        if temp not in links:
            links.append(temp)
    f.close
    if not links:
        xbmc.executebuiltin('Notification(MagicDust ,No IPTV Services Found,5000)')
        sys.exit("No IPTV Services Found")
    elif len(links) > 0:
        links = sorted(links, reverse = True)
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose IPTV Service", links)
        lookfor2 = 'http[^@]*'
        html=links[ret]
        link = re.findall(lookfor2, html, re.IGNORECASE)
        url = link[0]
        #lookfor = r'(?i)(' + lookfor + r'[^\n]*)\n(ht[^\n]*)'
        lookfor = r'(?i),(.*' + lookfor + r'[^\n]*)\n(ht[^\n]+)'

elif source == "USA\World-Fermiranda":
    url = "https://raw.githubusercontent.com/fermiranda/lista/master/MITv.m3u"
    lookfor2 = r'(?i)espn2[^\n]*\n(ht[^\/]*\/\/)([^\/]*)\/([^\/]*)\/([^\/]*)\/([^\/]*)'
    f = urllib.request.urlopen(url)
    html = f.read().decode('utf-8')
    found=[]
    links=[]
    found = re.findall(lookfor2, html)
    for item in found:
        temp={}    
        if item[2] == "live":
            temp="[B][UPPERCASE][COLOR=green]"+item[1]+"[/COLOR]:  [COLOR=FF00FFFF]"+item[3] +"[/COLOR][/UPPERCASE][/B]- " +item[0]+item[1]+"/get.php?username="+item[3]+"&password="+item[4]+"&type=m3u&output=hls@"
       	else:
            temp="[B][UPPERCASE][COLOR=green]"+item[1]+"[/COLOR]:  [COLOR=FF00FFFF]"+item[2] +"[/COLOR][/UPPERCASE][/B]- " +item[0]+item[1]+"/get.php?username="+item[2]+"&password="+item[3]+"&type=m3u&output=hls@"
        temp=temp.replace('\n', '').replace('\r', '')
        if temp not in links:
            links.append(temp)
    f.close
    if not links:
        xbmc.executebuiltin('Notification(MagicDust ,No IPTV Services Found,5000)')
        sys.exit("No IPTV Services Found")
    elif len(links) > 0:
        links = sorted(links, reverse = True)
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose IPTV Service", links)
        lookfor2 = 'http[^@]*'
        html=links[ret]
        link = re.findall(lookfor2, html, re.IGNORECASE)
        url = link[0]
        #lookfor = r'(?i)(' + lookfor + r'[^\n]*)\n(ht[^\n]*)'
        lookfor = r'(?i),(.*' + lookfor + r'[^\n]*)\n(ht[^\n]*)'

elif source == "USA-IPTV-ORG":
    url = "https://github.com/iptv-org/iptv/raw/master/streams/us.m3u"
    lookfor = r'(?i)status="([^"]+)",(.*' + lookfor + r'[^"]*)\n(ht[^#]*)'
elif source == "UK-IPTV-ORG":
    url = "https://github.com/iptv-org/iptv/raw/master/streams/uk.m3u"
    lookfor = r'(?i)status="([^"]+)",(.*' + lookfor + r'[^"]*)\n(ht[^#]*)'
elif source == "CA-IPTV-ORG":
    url = "https://github.com/iptv-org/iptv/raw/master/streams/ca.m3u"
    lookfor = r'(?i)status="([^"]+)",(.*' + lookfor + r'[^"]*)\n(ht[^#]*)'
elif source == "World-IPTVCAT":
    url = "https://github.com/bitsbb01/cat-scrapper/raw/master/data/all-streams.json"
    lookfor = r'(?s)(?i)('+ lookfor + r'[^"]*).+?link":[^"]*"([^"]*)"[^"]*"country": "([^"]*).+?"status": "([^"]*)'
elif source == "USA-IPTVCAT":
    url = "https://github.com/bitsbb01/cat-scrapperus/raw/master/data/countries/united%20states%20of%20america.json"
    lookfor = r'(?s)(?i)('+ lookfor + r'[^"]*).+?link":[^"]*"([^"]*)"[^"]*"country": "([^"]*).+?"status": "([^"]*)'
elif source == "UK-IPTVCAT":
    url = "https://github.com/bitsbb01/cat-scrapperuk/raw/master/data/countries/united%20kingdom.json"
    lookfor = r'(?s)(?i)('+ lookfor + r'[^"]*).+?link":[^"]*"([^"]*)"[^"]*"country": "([^"]*).+?"status": "([^"]*)'
elif source == "CAN-IPTVCAT":
    url = "https://github.com/bitsbb01/catscrapper_canada/raw/master/data/countries/canada.json"
    lookfor = r'(?s)(?i)('+ lookfor + r'[^"]*).+?link":[^"]*"([^"]*)"[^"]*"country": "([^"]*).+?"status": "([^"]*)'

elif source == "USA\World-GMTV":
    url = "https://raw.githubusercontent.com/khoebhoerhan/GMTV/main/GMTV.m3u"
    lookfor = r'(?i),(.*' + lookfor + r'[^\n]*)\n(ht\S*)'
else:
    sys.exit("No Extra Channels Found")

msg="Scraping " + name + " from " + source
xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))

user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36"
req = urllib.request.Request(url, headers={'User-Agent': user_agent}, method='GET')
f = urllib.request.urlopen(req)
html = f.read().decode('utf-8')

found=[]
links=[]

found = re.findall(lookfor, html)
for item in found:
    temp={}    
    if 'IPTV-ORG' in source:
        temp="[B][UPPERCASE][COLOR=green]"+item[1]+"[/COLOR]:  [COLOR=FF00FFFF]"+item[0] +"[/COLOR][/UPPERCASE][/B] - " +item[2]+"??"
        temp=temp.replace('\n', '').replace('\r', '')
    elif 'IPTVCAT' in source:
        temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]: [COLOR=FF00FFFF]"+item[2]+" [/COLOR][/UPPERCASE][/B]- " +item[3]+" "+item[1]+"??"
        temp=temp.replace('\n', '').replace('\r', '')
    else:
        temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]: [/UPPERCASE][/B]- " +item[1]+"??"
        temp=temp.replace('\n', '').replace('\r', '')
    if temp not in links and 'offline' not in temp:
        links.append(temp)
f.close

if not links:
    xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
    sys.exit("No Stable Channels Found")
elif len(links) > 0:
    links = sorted(links, reverse = False)
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Choose Stream", links)
    lookfor = 'http[^?]*'
    html=links[ret]
    link = re.findall(lookfor, html, re.IGNORECASE)
    if(ret)>-1:
#***find link within m3u8 subroutine***
        if 'IPTVCAT' in source:
            found=[]
            url = link[0]
            hdr = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36", "Accept-Language": "en-US"}
            req = urllib.request.Request(url, headers=hdr)
            file = urllib.request.urlopen(req)
            html = file.read().decode('utf-8')
            lookfor = r'(?s)(?i)(http[^?]*)'
            found = re.findall(lookfor, html)
            if 'm3u8' in found[0]:
                xbmc.executebuiltin('PlayMedia(' + found[0] + ')')
            else:
                xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + found[0] + '")')
#***END find link within m3u8 routine***
        elif 'm3u8' in link[0]:
            xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
        else:
            xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + link[0] + '")')
    else:
        sys.exit("No Stable Channels Found")
else:
    xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
    sys.exit("No Stable Channels Found")