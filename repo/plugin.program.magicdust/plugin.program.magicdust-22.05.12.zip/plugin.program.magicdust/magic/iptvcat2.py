import xbmc
import time

lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
if not lookfor:
    xbmc.executebuiltin('ActivateWindow(TVGuide)')
    time.sleep(.200)
    lookfor = xbmc.getInfoLabel('ListItem.ChannelName')

title="MagicDust "
msg="Searching: " + lookfor
xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
space=lookfor.find(' ')
name=lookfor
if space:
    lookfor =lookfor[0:space]

import re
import xbmcgui
from xbmcgui import ListItem

sources=['USA-IPTVCAT', 'USA-IPTV-ORG', 'USA-Fermiranda', '==============', 'UK-IPTVCAT', 'UK-IPTV-ORG', '==============', 'CAN-IPTVCAT', 'CA-IPTV-ORG']
dialog = xbmcgui.Dialog()
ret = dialog.select("Choose an Online Channel Source", sources)
source=sources[ret]

if source == "USA-IPTV-ORG":
    url = "https://github.com/iptv-org/iptv/raw/master/streams/us.m3u"
    lookfor = r'(?i)",(' + lookfor + r'[^"]*)\n(ht[^#]*)'
elif source == "UK-IPTV-ORG":
    url = "https://github.com/iptv-org/iptv/raw/master/streams/uk.m3u"
    lookfor = r'(?i)",(' + lookfor + r'[^"]*)\n(ht[^#]*)'
elif source == "CA-IPTV-ORG":
    url = "https://github.com/iptv-org/iptv/raw/master/streams/ca.m3u"
    lookfor = r'(?i)",(' + lookfor + r'[^"]*)\n(ht[^#]*)'

elif source == "USA-IPTVCAT":
    url = "https://github.com/ericziethen/ez-iptvcat-scraper/raw/master/data/countries/united%20states%20of%20america.json"
    lookfor = r'(?s)(?i)('+ lookfor + r'[^"]*).+?link":[^"]*"([^"]*).+?"status": "([^"]*)'
elif source == "UK-IPTVCAT":
    url = "https://github.com/ericziethen/ez-iptvcat-scraper/raw/master/data/countries/united%20kingdom.json"
    lookfor = r'(?s)(?i)('+ lookfor + r'[^"]*).+?link":[^"]*"([^"]*).+?"status": "([^"]*)'
elif source == "CAN-IPTVCAT":
    url = "https://github.com/ericziethen/ez-iptvcat-scraper/raw/master/data/countries/canada.json"
    lookfor = r'(?s)(?i)('+ lookfor + r'[^"]*).+?link":[^"]*"([^"]*).+?"status": "([^"]*)'

elif source == "USA-Fermiranda":
    url = "https://raw.githubusercontent.com/fermiranda/lista/master/MITv.m3u"
    lookfor = r'(?i)(' + lookfor + r'[^"]*)\n(ht[^#]*)'
else:
    sys.exit("No Extra Channels Found")

import urllib.request
from urllib.request import urlopen

f = urllib.request.urlopen(url)
html = f.read().decode('utf-8')

found=[]
links=[]

found = re.findall(lookfor, html)
for item in found:
    temp={}    
    if 'IPTV-ORG' in source:
        temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:  [COLOR=FF00FFFF]100%   [/COLOR][/UPPERCASE][/B]- " +item[1]+"??"
        temp=temp.replace('\n', '').replace('\r', '')
    elif 'IPTVCAT' in source:
        temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:  [COLOR=FF00FFFF]"+item[2]+"  [/COLOR][/UPPERCASE][/B]- " +item[1]+"??"
        temp=temp.replace('\n', '').replace('\r', '')
    else:
        temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:  [COLOR=FF00FFFF]100%   [/COLOR][/UPPERCASE][/B]- " +item[1]+"??"
        temp=temp.replace('\n', '').replace('\r', '')
    if temp not in links and 'offline' not in temp:
        links.append(temp)
f.close

if not links:
    xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
    sys.exit("No Stable Channels Found")
elif len(links) > 0:
    links = sorted(links, reverse = True)
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Choose Stream", links)
    lookfor = 'http[^?]*'
    html=links[ret]
    link = re.findall(lookfor, html, re.IGNORECASE)
    if(ret)>-1:
#***find link within m3u8 subroutine***
        if 'IPTVCAT' in source:
            found=[]
            url = link[0]
            hdr = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36", "Accept-Language": "en-US"}
            req = urllib.request.Request(url, headers=hdr)
            file = urllib.request.urlopen(req)
            html = file.read().decode('utf-8')
            lookfor = r'(?s)(?i)title=".+?(http[^?]*)'
            found = re.findall(lookfor, html)
            if 'm3u8' in found[0]:
                xbmc.executebuiltin('PlayMedia(' + found[0] + ')')
            else:
                xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + found[0] + '")')
#***END find link within m3u8 routine***
        elif 'm3u8' in link[0]:
            xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
        else:
            xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + link[0] + '")')
    else:
        sys.exit("No Stable Channels Found")
else:
    xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
    sys.exit("No Stable Channels Found")