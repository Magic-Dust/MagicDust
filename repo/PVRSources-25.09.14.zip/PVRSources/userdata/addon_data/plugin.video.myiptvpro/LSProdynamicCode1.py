# -*- coding: utf-8 -*-
#$pyFunction
def GetLSProData(page_data, Cookie_Jar, m):
    import re, base64, requests

    url = "https://streamtp11.com/global1.php?stream=disney2".replace("https://", "http://")
    html = requests.get(url).text

    # 1. Capturar el array tp
    tp_match = re.search(r'playbackURL=""\,.*?=(\[\[.*?\]\]);', html, re.DOTALL)
    if not tp_match:
        return ''
    tp = eval(tp_match.group(1))  # Convierte string a lista
    tp.sort(key=lambda x: x[0])

    # 2. Capturar las claves con doble return
    claves_match = re.search(r'{return\s(.*?)\;[\w\W\s]*?\{return\s(.*?)\;', html)
    if not claves_match:
        return ''
    k1 = int(claves_match.group(1))
    k2 = int(claves_match.group(2))
    k = k1 + k2

    # 3. Decodificar y construir URL
    playback_url = ''
    for _, b64 in tp:
        try:
            decoded = base64.b64decode(b64).decode('utf-8')
            digits = ''.join(filter(str.isdigit, decoded))
            char_code = int(digits) - k
            playback_url += chr(char_code)
        except:
            continue

    return playback_url
