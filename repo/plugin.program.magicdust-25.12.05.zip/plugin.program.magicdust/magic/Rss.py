import xbmc
import xbmcvfs
import xbmcgui
from xbmcgui import ListItem
import sys
import re
import xml.etree.ElementTree as ET
import requests
import json

addon_name="[B][COLOR skyblue]MagicDust[/COLOR][/B]"
icon='special://home/addons/plugin.program.magicdust/resources/media/fractureft.jpg'
userdata_path = xbmcvfs.translatePath('special://home/userdata/')
addon_path = xbmcvfs.translatePath('special://home/addons/skin.arctic.zephyr.mod/1080i/')
guisettings_file = userdata_path + 'guisettings.xml'
rss_file = userdata_path + 'RssFeeds.xml'
custom_rss = addon_path + 'Custom_Rss.xml'

if not xbmcvfs.exists(rss_file):
    msg = 'RssFeeds.xml file not found'
    xbmcgui.Dialog().notification(addon_name, msg, icon, 2000, False)
    sys.exit(1)
if not xbmcvfs.exists(custom_rss):
    msg = 'Custom_Rss.xml file not found'
    xbmcgui.Dialog().notification(addon_name, msg, icon, 2000, False)
    sys.exit(1)
with xbmcvfs.File(rss_file) as file:
  rssxml = file.read()
lookfor = r'set id="([^"]+)[^-]+--([^!]+)'
feeds=re.findall(lookfor, rssxml, re.IGNORECASE)
feedlist = []
for item in feeds:
    temp={}    
    #temp="[B][UPPERCASE][COLOR=skyblue]" + item[1] + "[/COLOR][/UPPERCASE][/B]    :" + item[0] + "?"
    temp=item[0] + " " + "[B][UPPERCASE][COLOR=skyblue]" + item[1] + "[/COLOR][/UPPERCASE][/B]"
    feedlist.append(temp)
file.close
if not feedlist:
    msg = 'No feeds found in RssFeeds.xml file'
    xbmcgui.Dialog().notification(addon_name, msg, icon, 2000, False)
    sys.exit(1)
temp={}    
temp="0 [B][UPPERCASE][COLOR=red]Turn Off Feeds[/COLOR][/UPPERCASE][/B]"
feedlist.append(temp)
#feedlist = sorted(feedlist, reverse = False)
msg = 'Pick an Rss feed'
ret = xbmcgui.Dialog().select(msg, feedlist)
html=feedlist[ret]
if "Turn Off" in html:
    try:
        query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"lookandfeel.enablerssfeeds", "value":false}, "id":1}'
        xbmc.executeJSONRPC(query)
        msg = 'Rss Feeds turned off.'
        xbmcgui.Dialog().notification(addon_name, msg, icon, 2000, False)
        sys.exit(0)
    except:
        #msg = 'Error disabling Rss Feeds'
        #xbmcgui.Dialog().notification(addon_name, msg, icon, 2000, False)
        sys.exit(1)
else:
    #lookfor = r'(\d[^\s?]*)'
    lookfor = r'(\d[^\s]*)'
    feed = re.findall(lookfor, html, re.IGNORECASE)[:1] 
    sfeed = feed[0]
    msg = 'Rss Feeds turned on, selected feed: ' + str(sfeed)
    try:
        tree = ET.parse(custom_rss)
        root = tree.getroot()
        element = root[2][0][10]
        element.text = str(sfeed)
        tree.write(custom_rss, encoding='utf-8', xml_declaration=True)
        element = root[2][1][10]
        element.text = str(sfeed)
        tree.write(custom_rss, encoding='utf-8', xml_declaration=True)
    except:
        msg = 'Error Changing Rss Set to ' + str(sfeed)
        xbmcgui.Dialog().notification(addon_name, msg, icon, 2000, False)
        sys.exit(1)
    finally:
        query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"lookandfeel.enablerssfeeds", "value":true}, "id":1}'
        xbmc.executeJSONRPC(query)
        xbmc.executebuiltin('Action(reloadCustom_Rss)')
        xbmcgui.Dialog().notification(addon_name, msg, icon, 2000, False)
        sys.exit(0)
sys.exit(0)