import xbmc
import re
import xbmcgui
from xbmcgui import ListItem
import xbmcvfs
import time

filename = xbmcvfs.translatePath('special://home/addons/plugin.program.magicdust/magic/channels.txt')
with xbmcvfs.File(filename) as file:
  html = file.read()
lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
if not lookfor:
    xbmc.executebuiltin('ActivateWindow(TVGuide)')
    time.sleep(.500)
    lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
found=[]
links=[]
lookfor2=r'Channel:,([^,]*),(' + lookfor + r'),([^,]*),(.*)'
found = re.findall(lookfor2, html)
for item in found:
    temp={}
    temp="[B][UPPERCASE][COLOR=skyblue]"+item[0]+"[/COLOR]:    [COLOR=FF00FFFF]"+item[2]+"[/COLOR][/UPPERCASE][/B]  @"+item[3].replace('\n', ' ').replace('\r', '')    
    temp=temp.replace('\n', '').replace('\r', '')
    if temp not in links:
        links.append(temp)
file.close
if not links:
    import urllib.request
    from urllib.request import urlopen
    name=lookfor
    title="MagicDust "
    addon_name="[B][COLOR skyblue]MagicDust[/COLOR][/B]"
    icon='special://home/addons/plugin.program.magicdust/resources/media/fractureft.jpg'
    filename = xbmcvfs.translatePath('special://home/addons/plugin.program.magicdust/magic/lsp/iptv.xml')
    with xbmcvfs.File(filename) as file:
      html = file.read()
    html=html.replace('\r', '')
    IPTVsearch = r'(?i)<item>\n<title>([^<]+)[^,]+[^\n]+\n<expres>([^<]+)<\/expres>\n<page>([^<]+)'
    found=[]
    links=[]
    found = re.findall(IPTVsearch, html)
    for item in found:
        temp={}
        temp="[B][UPPERCASE]"+item[0]+"[/UPPERCASE][/B]- " +item[2] +"@" +item[1] +"|"
        temp=temp.replace('\n', '').replace('\r', '')
        if temp not in links:
            links.append(temp)
    file.close
    if not links:
        #xbmc.executebuiltin('Notification(MagicDust ,No IPTV Services Found,5000)')
        msg = 'No IPTV Services Found'
        xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
        sys.exit("No IPTV Services Found")
    elif len(links) > 0:
        links = sorted(links, reverse = False)
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose IPTV Service Source", links)
        lookfor10 = 'http[^@]*'
        html=links[ret]
        msg="Scraping " + name + " from " + html
        xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
        Sourcesearch = 'http[^@]*'
        Sourcesearch=Sourcesearch.replace('amp;', '')
        link = re.findall(Sourcesearch, html, re.IGNORECASE)
        url = link[0]
        url=url.replace('&amp;', '&')
        f = urllib.request.urlopen(url)
        html = f.read().decode('utf-8')
        #xbmc.log('The value of IPTVlist url is: ' + str(html) ,  xbmc.LOGINFO)
        found=[]
        links=[]
        #iptvscan = ',(' + name +'[^\n]*)\n(ht[^\s]*)'
        iptvscan = '(?i)(?s)(' + name +'[^\n,]*)\n(ht[^\s]*)'        
        found = re.findall(iptvscan, html)
        #xbmc.log('The value of Links found is: ' + str(found) ,  xbmc.LOGINFO)
        for item in found:
            temp={}    
            temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR][/UPPERCASE][/B] - " +item[1]+"$$"
            temp=temp.replace('\n', '').replace('\r', '')
            if temp not in links and 'offline' not in temp:
                links.append(temp)
        f.close
        if not links:
            #xbmc.executebuiltin('Notification(MagicDust ,No Channels Found,5000)')
            msg="No Channels Found"
            xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
            sys.exit("No Stable Channels Found")
        elif len(links) > 0:
            links = sorted(links, reverse = False)
            dialog = xbmcgui.Dialog()
            ret = dialog.select("Choose Stream", links)
            html=links[ret]
            checker = "plugin"
            if checker in html:
                lookfor = 'plugin[^$]*'
            else:
                lookfor = 'http[^$]*'
            link = re.findall(lookfor, html, re.IGNORECASE)
            #if(ret)>-1:
            if len(link[0]) > 0:
                if "m3u8" in link[0]:
                    direct = 0
                else:
                    direct = 1
                if direct: 
                    msg="running f4m " + link[0]
                    #xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
                    xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
                    xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
                    #xbmc.executebuiltin('PlayMedia(plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&url=' + link[0] + ')')
                else:
                    msg="direct player " + link[0]
                    #xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
                    xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
                    xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
            else:
                msg="Unplayable Channel"
                #xbmc.executebuiltin('Notification(MagicDust ,Unplayable Channel,5000)')
                xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
                sys.exit("Unplayable Channel")
    else:
        msg="No Channel Found"
        #xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
        xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
        sys.exit("No Stable Channels Found")
else:
    name = lookfor
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Choose a Local Channel Source", links)
    if(ret)>-1:
        lookfor = r'@(.*)'
        html=links[ret]
        link = re.findall(lookfor, html, re.IGNORECASE)
        if '.ts' in link[0]:
            xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + link[0] + '")')
        elif 'f4m' in link[0]:
            xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + link[0] + '")')
        else:
            xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
    else:
        msg="No Channel Found"
        #xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
        xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
        sys.exit("No Stable Channels Found")