import xbmc
import xbmcgui
from xbmcgui import ListItem

#cmd = 'Skin.SetString(HomeItem.1.Widget, XXXX)'
#xbmc.executebuiltin(cmd)

#cmd = 'ClearProperty(HomeItem.1, Home)'
#xbmc.executebuiltin(cmd)
 

#<onload condition="!$EXP[HomeIsModernMultiWidgets] + !$EXP[HomeIsVerticalMultiWidgets]">SetProperty(TMDbHelper.WidgetContainer,301,home)</onload>
#<onunload>ClearProperty(TMDbHelper.WidgetContainer,home)</onunload>

#Container(300).ListItem.Property(widget)

#        "mainmenu",
#        "movies",
#        "widgetName",
#        "Trending"

#        "mainmenu",
#        "movies",
#        "widgetPath",
#        "plugin://plugin.video.themoviedb.helper/?info=trending_day&tmdb_type=movie&widget=true&reload=$INFO[Window(Home).Property(TMDbHelper.Widgets.Reload)]&reload=$INFO[Window(Home).Property(TMDbHelper.Widgets.Reload)]"

#cmd = 'Skin.SetString(HomeItem.1.Widget, plugin://plugin.video.themoviedb.helper/?info=upcoming&amp;tmdb_type=movie)'
#xbmc.executebuiltin(cmd)

#cmd = 'ClearProperty(HomeItem.1, Home)'
#xbmc.executebuiltin(cmd) 

#cmd= Container(300).ListItem.Property(widget)
#tmdh widget container 30111
cmd = Container(300).mainmenu.movies.widgetPath
xbmc.executebuiltin('Notification(MagicDust ,cmd,5000)')

#sys.exit("bye")