import xbmc
import os
import json
import xbmcvfs
import xbmcgui
from xbmcgui import ListItem

name = xbmc.getInfoLabel('ListItem.Label')
url = xbmc.getInfoLabel('ListItem.FileNameAndPath')
iconimage = xbmc.getInfoLabel('ListItem.Icon')
fanart = xbmc.getInfoLabel('ListItem.Art(fanart)')
mode = 1
if '.m3u8' in url:
    lookfor=2
elif '.ts' in url:
    lookfor=2
elif '.pvr' in url:
    lookfor=2
elif 'play?' in url:
    lookfor=2
else
    lookfor=1

if lookfor == 1:
    favorites = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.myiptvpro/favorites')
    favList = []
    try:
        name = name.encode('utf-8', 'ignore') if six.PY2 else name
    except:
        pass
    if os.path.exists(favorites) is False:
        favList.append((name, url, iconimage, fanart, mode, playlist, regexs))
        with xbmcvfs.File(favorites, "w") as a:
            a.write(json.dumps(favList))
    else:
        a = xbmcvfs.File(favorites).read()
        data = json.loads(a)
        data.append((name, url, iconimage, fanart, mode))
        with xbmcvfs.File(favorites, "w") as b:
            b.write(json.dumps(data))

    addon_name="[B][COLOR skyblue]MagicDust[/COLOR][/B]"
    msg = ' List Added to Favorites'
    icon='special://home/addons/plugin.program.magicdust/resources/media/fractureft.jpg'
    xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
    
else:
    favorites = xbmcvfs.translatePath('special://home/addons/plugin.program.magicdust/magic/channels.txt')
    
    favList = []
    try:
        name = name.encode('utf-8', 'ignore') if six.PY2 else name
    except:
        pass
    if os.path.exists(favorites) is False:
        favList.append((name, url, iconimage, fanart, mode, playlist, regexs))
        with xbmcvfs.File(favorites, "w") as a:
            a.write(json.dumps(favList))
    else:
        a = xbmcvfs.File(favorites).read()
        data = json.loads(a)
        data.append((name, url, iconimage, fanart, mode))
        with xbmcvfs.File(favorites, "w") as b:
            b.write(json.dumps(data))

    addon_name="[B][COLOR skyblue]MagicDust[/COLOR][/B]"
    msg = ' Channel Added to Favorites'
    icon='special://home/addons/plugin.program.magicdust/resources/media/fractureft.jpg'
    xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)

