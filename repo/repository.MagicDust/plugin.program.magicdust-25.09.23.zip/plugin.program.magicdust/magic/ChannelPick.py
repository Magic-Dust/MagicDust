import xbmc
import time
import re
import xbmcvfs
import xbmcgui
from xbmcgui import ListItem
import urllib.request
from urllib.request import urlopen

lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
if not lookfor:
    xbmc.executebuiltin('ActivateWindow(TVGuide)')
    time.sleep(.200)
    lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
space=lookfor.find(' ')
if space > 1:
    lookfor =lookfor[0:space]
name=lookfor
title="MagicDust "
addon_name="[B][COLOR skyblue]MagicDust[/COLOR][/B]"
icon='special://home/addons/plugin.program.magicdust/resources/media/fractureft.jpg'
#filename = xbmcvfs.translatePath('special://home/addons/plugin.program.magicdust/magic/lsp/iptv.xml')
url = 'https://raw.githubusercontent.com/Magic-Dust/MagicDust/refs/heads/master/repo/iptv.xml'
#xbmc.log('MagicS- The url of Source Selected is: ' + str(url) ,  xbmc.LOGINFO)
f = urllib.request.urlopen(url)
html = f.read().decode('utf-8')
html=html.replace('\r', '')
IPTVsearch = r'(?i)<item>\n<title>([^<]+)[^,]+[^\n]+\n<expres>([^<]+)<\/expres>\n<page>([^<]+)'
found=[]
links=[]
found = re.findall(IPTVsearch, html)
for item in found:
    temp={}
    temp="[B][UPPERCASE]"+item[0]+"[/UPPERCASE][/B]- " +item[2] +"@" +item[1] +"|"
    temp=temp.replace('\n', '').replace('\r', '')
    if temp not in links:
        links.append(temp)
f.close
if not links:
    msg = 'No IPTV Services Found in iptv.xml'
    xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
    sys.exit("No IPTV Services Found")
if len(links) > 0:
    #links = sorted(links, reverse = False)
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Choose IPTV Service Source", links)
    html=links[ret]
    #xbmc.log('MagicS- The value of Link Selected is: ' + str(html) ,  xbmc.LOGINFO)
    msg="Scraping " + name + " from " + html
    #xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
    xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
    Sourcesearch = 'http[^@]*'
    link = re.findall(Sourcesearch, html, re.IGNORECASE)
    if "Loop" in html:
        iptvscan = '(?i)(?s)(' + name +'[^\n,]*)\n(plug[^\s]*)'
    elif "Titan" in html:
        iptvscan = '(?i)(?s)(' + name +'[^\n,]*)\n(plug[^\n]*)'
    else:
        iptvscan = '(?i)(?s)(' + name +'[^\n,]*)\n(ht[^\s]*)'
    #link=link.replace('&amp;', '&')
    url = link[0]
    url=url.replace('&amp;', '&')
    #xbmc.log('MagicS- The url of Source Selected is: ' + str(url) ,  xbmc.LOGINFO)
    f = urllib.request.urlopen(url)
    html = f.read().decode('utf-8')
    #xbmc.log('MagicS- The value of IPTVlist is: ' + str(html) ,  xbmc.LOGINFO)
    found=[]
    links=[]
    found = re.findall(iptvscan, html)
    #xbmc.log('MagicS- The Links found in url are: ' + str(found) ,  xbmc.LOGINFO)
    for item in found:
        temp={}    
        temp="[B][UPPERCASE][COLOR=skyblue]"+item[0]+"[/COLOR][/UPPERCASE][/B] - " +item[1]+"$$"
        temp=temp.replace('\n', '').replace('\r', '')
        if temp not in links and 'offline' not in temp:
            links.append(temp)
    f.close
    if not links:
        msg = 'No Channels Found'
        xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
        #xbmc.executebuiltin('Notification(MagicDust ,No Channels Found,5000)')
        sys.exit("No Stable Channels Found")
    elif len(links) > 0:
        links = sorted(links, reverse = False)
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose Stream", links)
        html=links[ret]
        if "plugin" in html:
            lookfor = 'plugin[^$]*'
        else:
            lookfor = 'http[^$]*'
        link = re.findall(lookfor, html, re.IGNORECASE)
        if len(link[0]) > 0:
            if "m3u8" in link[0]:
                direct = 0
            elif "plugin" in link[0]:            
                direct = 0
            else:
                direct = 1
            if direct: 
                msg="running f4m " + link[0]
                #xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
                xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
                #xbmc.executebuiltin('PlayMedia(plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&url=' + link[0] + ')')
                xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
            else:
                msg="direct player " + link[0]
                #xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
                xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
                xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
        else:
            msg="Unplayable Channel"
            #xbmc.executebuiltin('Notification(MagicDust ,Unplayable Channel,5000)')
            xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
            sys.exit("No Stable Channels Found")
    else:
        msg="No Channel Found"
        #xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
        xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
        sys.exit("No Stable Channels Found")
else:
    msg="No IPTV Services Found"
    #xbmc.executebuiltin('Notification(MagicDust ,No IPTV Services Found,5000)')
    xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
    sys.exit("No IPTV Services Found")