import sys, re, xbmc, xbmcgui, urllib.request, time
from xbmcgui import ListItem
from urllib.request import urlopen

def run():
    channel = xbmc.getInfoLabel('ListItem.ChannelName')
    if not channel:
        xbmc.executebuiltin('ActivateWindow(TVGuide)')
        time.sleep(.200)
        channel = xbmc.getInfoLabel('ListItem.ChannelName')
    title="MagicIPTV"
    msg="Searching: for SCV Provider M3U lists "
    xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
    space=channel.find(' ')
    if space > 1:
        channel = channel[0:space]
    name=channel
    url = 'https://onedrive.live.com/download?cid=E28369FD4B5A92DC&resid=E28369FD4B5A92DC%21155&authkey=AAZvbY0ngUf6rKE'
    lookfor2 = r'(?i),.*espn[^\n]*\n(ht[^\/]*\/\/)([^\/]*)\/([^\/]*)\/([^\/]*)\/([^\/]*)'
    #url = "https://raw.githubusercontent.com/trincowski/iptv/main/Desportivos_World.m3u8"
    #lookfor2 = r'(?i)BT SPORT 1[^\n]*\n(ht[^\/]*\/\/)([^\/]*)\/([^\/]*)\/([^\/]*)\/([^\/]*)'
    f = urllib.request.urlopen(url)
    html = f.read().decode('utf-8')
    found=[]
    links=[]
    found = re.findall(lookfor2, html)
    for item in found:
        temp={}
        temp="[B][UPPERCASE][COLOR=green]"+item[1]+"[/COLOR]:  [COLOR=FF00FFFF]"+item[3] +"[/COLOR][/UPPERCASE][/B]- " +item[0]+item[1]+"/get.php?username="+item[3]+"&password="+item[4]+"&type=m3u@"
        temp=temp.replace('\n', '').replace('\r', '')
        if temp not in links:
            links.append(temp)
    f.close
    if not links:
        xbmc.executebuiltin('Notification(MagicDust ,No IPTV Services Found,5000)')
        sys.exit("No IPTV Services Found")
    elif len(links) > 0:
        links = sorted(links, reverse = False)
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose IPTV Service List", links)
        lookfor2 = 'http[^@]*'
        html=links[ret]
        link = re.findall(lookfor2, html, re.IGNORECASE)
        url = link[0]
        lookfor = r'(?i),(.*' + name + r'[^\n]*)\n(ht[^\n]*)'
    msg="Scraping " + name + " from m3u list"
    xbmc.executebuiltin('Notification(%s, %s, 5000)'%(title, msg))
    user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36"
    req = urllib.request.Request(url, headers={'User-Agent': user_agent}, method='GET')
    f = urllib.request.urlopen(req)
    html = f.read().decode('utf-8')
    found=[]
    links=[]
    found = re.findall(lookfor, html)
    for item in found:
        temp={}    
        temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR][/UPPERCASE][/B] - " +item[1]+"??"
        temp=temp.replace('\n', '').replace('\r', '')
        if temp not in links and 'offline' not in temp:
            links.append(temp)
    f.close
    if not links:
        xbmc.executebuiltin('Notification(MagicIPTV ,No Channel Found,5000)')
        sys.exit("No Stable Channels Found")
    elif len(links) > 0:
        links = sorted(links, reverse = False)
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose Stream", links)
        lookfor = 'http[^?]*'
        html=links[ret]
        link = re.findall(lookfor, html, re.IGNORECASE)
        if(ret)>-1:
            if 'm3u8' in link[0]:
                xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
                sys.exit("Direct Playing "+ link[0])
            else:
                xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + link[0] + '")')
                sys.exit("F4M Playing "+ link[0])
        else:
            sys.exit("No Stable Channels Found")
    else:
        xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
        sys.exit("No Stable Channels Found")
run()