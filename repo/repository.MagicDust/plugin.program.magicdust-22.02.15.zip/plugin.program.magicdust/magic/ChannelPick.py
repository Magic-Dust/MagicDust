import xbmc
import re
import xbmcgui
from xbmcgui import ListItem
import xbmcvfs
import time

filename = xbmcvfs.translatePath('special://home/addons/plugin.program.magicdust/magic/channels.txt')
with xbmcvfs.File(filename) as file:
  html = file.read()
lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
if not lookfor:
  xbmc.executebuiltin('ActivateWindow(TVGuide)')
  time.sleep(.200)
  lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
found=[]
links=[]
lookfor = r'Channel:,([^,]*),(' + lookfor + r'),([^,]*),(.*)'
found=re.findall(lookfor, html)

for item in found:
    temp={}
    temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:    [COLOR=FF00FFFF]"+item[2]+"[/COLOR][/UPPERCASE][/B]  @"+item[3].replace('\n', ' ').replace('\r', '')
    links.append(temp)

if not links:
    lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
    if not lookfor:
      xbmc.executebuiltin('ActivateWindow(TVGuide)')
      time.sleep(.200)
      lookfor = xbmc.getInfoLabel('ListItem.ChannelName')

    space=lookfor.find(' ')
    if space:
        lookfor =lookfor[0:space]

    source="USA-IPTVCAT"
    url = "https://raw.githubusercontent.com/ericziethen/ez-iptvcat-scraper/master/data/countries/united%20states%20of%20america.json"
    lookfor = r'(?s)(?i)('+ lookfor + r'[^"]*).+?link":[^"]*"([^?]*).+?"status": "([^"]*)'

    import urllib.request
    from urllib.request import urlopen

    f = urllib.request.urlopen(url)
    html = f.read().decode('utf-8')

    found=[]
    links=[]

    found = re.findall(lookfor, html)
    for item in found:
        temp={}    
        temp="[B][UPPERCASE][COLOR=green]"+item[0]+"[/COLOR]:  [COLOR=FF00FFFF]"+item[2]+"    [/COLOR][/UPPERCASE][/B]- " +item[1]+"??"
        temp=temp.replace('\n', '').replace('\r', '')
        if temp not in links and 'offline' not in temp:
            links.append(temp)
    f.close

    if not links:
        xbmc.executebuiltin('Notification(MagicDust ,No Channel Found,5000)')
        sys.exit("No Stable Channels Found")
    elif len(links) > 0:
        links = sorted(links, reverse = True)
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose Stream", links)
        lookfor = 'http[^?]*'
        html=links[ret]
        link = re.findall(lookfor, html, re.IGNORECASE)
        if(ret)>-1:
            if 'm3u8' in link[0]:
                xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
            else:
                xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + link[0] + '")')
        else:
            sys.exit("No Stable Channels Found")
else:
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Choose a Local Channel Source", links)
    if(ret)>-1:
        lookfor = r'@(.*)'
        html=links[ret]
        link = re.findall(lookfor, html, re.IGNORECASE)
        if '.ts' in link[0]:
            xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + link[0] + '")')
        elif 'f4m' in link[0]:
            xbmc.executebuiltin('PlayMedia("plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=' + link[0] + '")')
        else:
            xbmc.executebuiltin('PlayMedia(' + link[0] + ')')
    else:
        sys.exit("No Stable Channels Found")