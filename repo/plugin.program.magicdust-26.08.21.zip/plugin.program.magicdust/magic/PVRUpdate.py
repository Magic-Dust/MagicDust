import xbmcvfs
import xbmcgui

def copy_files(source_path, destination_path):
    msg = 'Error testing file: '
    if not xbmcvfs.exists(destination_path):
        xbmcvfs.mkdirs(destination_path)
    if xbmcvfs.exists(source_path):
        try:
            xbmcvfs.copy(source_path, destination_path)
            msg = 'Successfully copied: ' + source_path
        except:
            msg = 'Failed to copy: ' + source_path
    else:
        msg = 'Source does not exist: ' + source_path

    addon_name="[B][COLOR skyblue]MagicDust[/COLOR][/B]"
    icon='special://home/addons/plugin.program.magicdust/resources/media/fractureft.jpg'
    xbmcgui.Dialog().notification(addon_name, msg, icon, 2000, False)

#IPTV-Merge lists
source_path = "https://github.com/Magic-Dust/MagicDust/raw/refs/heads/master/repo/XML/data.db"
destination_path = "special://home/userdata/addon_data/plugin.program.iptv.merge/data.db"
copy_files(source_path, destination_path)

#LSP lists
source_path = "https://github.com/Magic-Dust/MagicDust/raw/refs/heads/master/repo/XML/source_file"
destination_path = "special://home/userdata/addon_data/plugin.video.live.streamspro/source_file"
copy_files(source_path, destination_path)

#aliundeplaylists lists
source_path = "https://github.com/Magic-Dust/MagicDust/raw/refs/heads/master/repo/XML/playLists.txt"
destination_path = "special://home/userdata/addon_data/plugin.video.aliundeplaylists/playLists.txt"
copy_files(source_path, destination_path)

#IPTV.Simple IPTV-Merge list
source_path = "https://github.com/Magic-Dust/MagicDust/raw/refs/heads/master/repo/XML/instance-settings-1.xml"
destination_path = "special://home/userdata/addon_data/pvr.iptvsimple/instance-settings-1"
copy_files(source_path, destination_path)
