import xbmc
import time
import re
import xbmcvfs
import xbmcgui
from xbmcgui import ListItem
import urllib.request
from urllib.request import urlopen

lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
if not lookfor:
    xbmc.executebuiltin('ActivateWindow(TVGuide)')
    time.sleep(.200)
    lookfor = xbmc.getInfoLabel('ListItem.ChannelName')
space=lookfor.find(' ')
if space > 1:
    lookfor =lookfor[0:space]
name=lookfor
title="MagicDust "
addon_name="[B][COLOR skyblue]MagicDust[/COLOR][/B]"
icon='special://home/addons/plugin.program.magicdust/resources/media/fractureft.jpg'

#new guide category
sources=['Guide Group', 'Channel Search', 'Cancel']
dialog = xbmcgui.Dialog()
ret = dialog.select("Select an Option", sources)
if ret == -1:
    msg="Channel Search Cancelled"
    xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
    sys.exit("Cancelled")
source=sources[ret]
if source == "Guide Group":
    xbmc.executebuiltin("SendClick(28)")
    sys.exit("Category Switched")
elif source == "Cancel":
    msg = "Cancelled"
    xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
    sys.exit("Cancelled")
#new guide category

url = 'https://raw.githubusercontent.com/Magic-Dust/MagicDust/refs/heads/master/repo/iptv.xml'
f = urllib.request.urlopen(url)
html = f.read().decode('utf-8')
html=html.replace('\r', '')
IPTVsearch = r'(?i)<item>\n<title>([^<]+)[^,]+[^\n]+\n<expres>([^<]+)<\/expres>\n<page>([^<]+)'
found=[]
links=[]
found = re.findall(IPTVsearch, html)
for item in found:
    temp={}
    temp="[B][COLOR skyblue][UPPERCASE]"+item[0]+"[/UPPERCASE][/COLOR][/B] - " +item[2]
    temp=temp.replace('\r', '')
    if temp not in links:
        links.append(temp)
f.close
if not links:
    msg = 'No IPTV Services Found in iptv.xml'
    xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
    sys.exit("No IPTV Services Found")
if len(links) > 0:
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Choose IPTV Service Source", links)
    if ret == -1:
        msg="Channel Search Cancelled"
        xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
        sys.exit("Channel Search Cancelled")
    html=links[ret]
    #xbmc.log('MagicS- The value of Link Selected is: ' + str(html) ,  xbmc.LOGINFO)
    msg="Scraping " + name + " from " + html
    xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
    Sourcesearch =  r'http[^\n]*'
    link = re.findall(Sourcesearch, html, re.IGNORECASE)
    iptvscan = '(?i)(?s)(' + name +'[^\n,]*)\n(ht[^\s]*)'
    url = link[0]
    url=url.replace('&amp;', '&')
    f = urllib.request.urlopen(url)
    html = f.read().decode('utf-8')
    #xbmc.log('MagicS- The value of IPTVlist is: ' + str(html) ,  xbmc.LOGINFO)
    found=[]
    links=[]
    found = re.findall(iptvscan, html)
    #xbmc.log('MagicS- The Links found in url are: ' + str(found) ,  xbmc.LOGINFO)
    for item in found:
        temp={}
        temp="[B][UPPERCASE][COLOR=skyblue]"+item[0]+"[/COLOR][/UPPERCASE][/B] - " +item[1]
        temp=temp.replace('\r', '')
        if temp not in links and 'offline' not in temp:
            links.append(temp)
    f.close
    if not links:
        msg = 'No Channels Found'
        xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
        sys.exit("No Stable Channels Found")
    elif len(links) > 0:
        links = sorted(links, reverse = False)
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose Stream", links)
        if ret == -1:
            msg="Channel Search Cancelled"
            xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
            sys.exit("Channel Search Cancelled")
        html=links[ret]
        if "plugin" in html:
            lookfor = 'plugin[^\n]+'
        else:
            lookfor = 'http[^\s\n]+'
        link = re.findall(lookfor, html, re.IGNORECASE)
        if len(link[0]) > 0:
            if 'cord-cutter' in link[0] or '1tv41' in link[0] or 'nocable' in link[0] or 'tvmate' in link[0]:
                direct = 0
                msg="f4m TSDOWNLOADER" + link[0]
                link[0] = link[0].replace('plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&url=', '')
                link[0] = link[0].replace('plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url=', '')
                link[0] = link[0].replace('plugin://plugin.video.f4mTester/?&url=', '')
                link[0] = link[0].replace('.m3u8', '')
                link[0] = link[0].replace('.ts', '')
            else:
                direct = 4
                msg="KODI Direct" + link[0]
            if direct==0:
                xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
                xbmc.executebuiltin('PlayMedia(plugin://plugin.video.f4mTester/?url='+link[0]+')')
            else:
                xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
                xbmc.executebuiltin('PlayMedia('+link[0]+')')
        else:
            msg="Unplayable Channel"
            xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
            sys.exit("No Stable Channels Found")
    else:
        msg="No Channel Found"
        xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)
        sys.exit("No Stable Channels Found")
else:
    msg="No IPTV Services Found"
    xbmcgui.Dialog().notification(addon_name, msg, icon, 5000, False)